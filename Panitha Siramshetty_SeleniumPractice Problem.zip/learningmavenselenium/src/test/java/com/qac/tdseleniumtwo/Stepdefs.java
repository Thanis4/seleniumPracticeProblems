package com.qac.tdseleniumtwo;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.MyStoreContactUsPage;
import pageobjects.MyStoreCreateAnAccountPage;
import pageobjects.MyStoreHomePage;
import pageobjects.MyStoreItemAddedToCartWindow;
import pageobjects.MyStoreItemDescriptionPage;
import pageobjects.MyStoreMyAccountPage;
import pageobjects.MyStorePageObject;
import pageobjects.MyStoreSearchItem;
import pageobjects.MyStoreSearchResultsPage;
import pageobjects.MyStoreShoppingCartPage;
import pageobjects.MyStoreSignInPage;

public class Stepdefs
{
	MyStoreHomePage homePage = MyStoreHomePage.GetInstance();
	MyStoreSignInPage signInPage = MyStoreSignInPage.GetInstance();
	MyStoreCreateAnAccountPage createAccountPage = MyStoreCreateAnAccountPage.GetInstance();
	MyStoreMyAccountPage myAccoutnPage = MyStoreMyAccountPage.GetInstance();
	MyStoreContactUsPage contactUsPage = MyStoreContactUsPage.GetInstance();
	MyStoreSearchItem searchItem = MyStoreSearchItem.GetInstance();
	MyStoreSearchResultsPage searchItems = MyStoreSearchResultsPage.GetInstance();
	MyStoreItemAddedToCartWindow itemAddedToCart = MyStoreItemAddedToCartWindow.GetInstance();
	MyStoreShoppingCartPage shoppingCart = MyStoreShoppingCartPage.GetInstance();
	MyStoreItemDescriptionPage itemDescription = MyStoreItemDescriptionPage.GetInstance();
	MyStorePageObject signout = MyStorePageObject.GetInstance();

	@Given("^user is on homepage$")
	public void user_is_on_homepage() throws Exception
	{
		homePage.NavigateToThisPage();
	}

	@When("^user navigates to signinpage$")
	public void user_navigates_to_signinpage()
	{
		homePage.NavigateToSignInPage();
	}

	@When("user begins registration")
	public void user_begins_registration()
	{
		signInPage.CreateAnAccount();
	}

	@When("user enters default data")
	public void user_enters_default_data()
	{
		createAccountPage.EnterAccountDetails();
	}

	@When("user logs out")
	public void user_logs_out()
	{
		myAccoutnPage.SignOut();
	}

	@Then("verify signinpage title")
	public void verify_signinpage_title()
	{
		signInPage.VerifyTitle();
	}

	@When("user signs in")
	public void user_signs_in()
	{
		signInPage.SignIn();
	}

	@Then("verify myaccountpage title")
	public void verify_myaccountpage_title()
	{
		myAccoutnPage.VerifyTitle();
	}

	@When("user navigates to contactuspage")
	public void user_navigates_to_contactuspage()
	{
		myAccoutnPage.NavigateToContactUsPage();
	}

	@Then("verify contactuspage title")
	public void verify_contactuspage_title()
	{
		contactUsPage.VerifyTitle();
	}

	@When("user enter dresses in search")
	public void user_enter_dresses_in_search()
	{
		searchItem.SearchForDresses();

	}

	@When("user searches for {string}")
	public void user_searches_for(String string)
	{

		searchItems.SearchforItem(string);
		searchItems.SelectItem(string);
	}

	/*
	 * @When("user searches for Faded Short Sleeve T-Shirt"") public void
	 * user_searches_for(String string) { // Write code here that turns the phrase
	 * above into concrete actions searchItems.SearchforFadedshirt(); }
	 */
	@When("user adds item to cart")
	public void user_adds_item_to_cart()
	{
		// Write code here that turns the phrase above into concrete actions
		itemDescription.AddItemToCart();

	}

	@When("user continues shopping")
	public void user_continues_shopping()
	{

		itemAddedToCart.pressContinueShoppingButton();
	}

	@When("user clicks shopping cart")
	public void user_clicks_shopping_cart()
	{

		itemDescription.goToShoppingCart();
	}

	@Then("user verifies {string} is in cart")
	public void user_verifies_is_in_cart(String string)
	{
		shoppingCart.VerifyItemPresenceInCart(string);
	}

	@Then("user signs out")
	public void user_signs_out()
	{
		// Write code here that turns the phrase above into concrete actions
		signout.SignOut();
	}
}
