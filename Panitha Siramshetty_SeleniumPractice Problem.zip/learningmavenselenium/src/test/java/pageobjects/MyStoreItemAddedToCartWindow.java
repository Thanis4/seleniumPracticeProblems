package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreItemAddedToCartWindow extends MyStorePageObject
{
	private static final Logger log = LogManager.getLogger(MyStoreHomePage.class);
	private static MyStoreItemAddedToCartWindow m_instance;

	// @FindBy(xpath =
	// "//*[@id=\"center_column\"]/ul/li/div/div[2]/div[2]/a[1]/span")
	// WebElement AddToCart;
	@FindBy(xpath = "//a[@title='View my shopping cart']")
	WebElement gotoShoppingCart;
	@FindBy(xpath = "//span[@class='continue btn btn-default button exclusive-medium']")
	WebElement ContinueShopping;

	private MyStoreItemAddedToCartWindow(WebDriver _driver)
	{
		log.debug("creating Home Page PageObject");

		m_pageTitle = "My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreItemDescriptionPage pressContinueShoppingButton()
	{
		log.debug("Click Continue Shopping");
		Selenium.Click(ContinueShopping);
		SeleniumHelper.Seconds(3);
		return MyStoreItemDescriptionPage.GetInstance();
	}

	public static MyStoreItemAddedToCartWindow GetInstance()
	{
		if (m_instance == null)
		{
			m_instance = new MyStoreItemAddedToCartWindow(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}
