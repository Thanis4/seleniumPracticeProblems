package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreItemDescriptionPage extends MyStorePageObject
{
	private static final Logger log = LogManager.getLogger(MyStoreHomePage.class);
	private static MyStoreItemDescriptionPage m_instance;

	@FindBy(linkText = "Sign in")
	WebElement signInButton;
	@FindBy(xpath = "//*[@id=\"contact-link\"]/a")
	WebElement contactUsButton;
	@FindBy(id = "search_query_top")
	WebElement searchBox;
	@FindBy(name = "submit_search")
	WebElement searchIcon;
	// @FindBy(xpath = "//*[@id=\"add_to_cart\"]/button/span")
	@FindBy(name = "Submit")
	WebElement AddToCart;
	@FindBy(xpath = "//a[@title='View my shopping cart']")
	WebElement goToShoppingCart;

	private MyStoreItemDescriptionPage(WebDriver _driver)
	{
		log.debug("creating Home Page PageObject");

		m_pageTitle = "My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreItemAddedToCartWindow AddItemToCart()
	{
		log.debug("Add Item to cart");
		Selenium.Click(AddToCart);
		SeleniumHelper.Seconds(3);

		// Selenium.VerifyTextInElement(_xpath, _"//*[@id="center_column"]/h1/span[2]");
		return MyStoreItemAddedToCartWindow.GetInstance();
	}

	public MyStoreShoppingCartPage goToShoppingCart()
	{
		log.debug("verify the shopping cart");
		Selenium.Click(goToShoppingCart);
		SeleniumHelper.Seconds(3);
		SeleniumHelper.VerifyTextPresentOnPage("Product successfully added to your shopping cart");

		// Selenium.VerifyTextInElement(_xpath, _"//*[@id="center_column"]/h1/span[2]");

//Selenium.Click(contactUsButton);
		return MyStoreShoppingCartPage.GetInstance();
	}

	public static MyStoreItemDescriptionPage GetInstance()
	{
		if (m_instance == null)
		{
			m_instance = new MyStoreItemDescriptionPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}