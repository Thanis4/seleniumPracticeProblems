package pageobjects;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import selenium.Selenium;
import selenium.SeleniumHelper;
public class MyStoreSearchPage extends MyStorePageObject
{
private static final Logger log = LogManager.getLogger(MyStoreSearchPage.class);
private static MyStoreSearchPage m_instance;

@FindBy(xpath = "//input[@name='search_query']")
WebElement search;

@FindBy(xpath = "//button[@name='submit_search']")
WebElement searchButton;

@FindBy(xpath = "//*[@class='heading-counter']")
WebElement itemName;

@FindBy(id = "add_to_cart")
WebElement shoppingCart;

private MyStoreSearchPage(WebDriver _driver)
{
m_pageTitle = "Search - My Store";
PageFactory.initElements(_driver, this);
}

public MyStoreSearchPage SearhForTShirts()
{
	Selenium.Input(search, "t-shirts");
	Selenium.Click(searchButton);
	SeleniumHelper.Seconds(3);
	return MyStoreSearchPage.GetInstance();
}

public MyStoreSearchPage SearchResult () {
	Selenium.VerifyTextInElement(itemName, "1 result has been found.");
	return MyStoreSearchPage.GetInstance();
}

public MyStoreSearchPage AddToCart () {
	Selenium.Click(shoppingCart);
	return MyStoreSearchPage.GetInstance();
}

public static MyStoreSearchPage GetInstance()
{
if (m_instance == null)
{
m_instance = new MyStoreSearchPage(SeleniumHelper.GetInstance().GetDriver());
}
return m_instance;
}
}

