package pageObjects;

import org.openqa.selenium.By;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.FindBy;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
//import selenium.Selenium;
import selenium.SeleniumHelper;


public class MyStoreSearchResultsPage extends MyStorePageObject
{

	private static final Logger log = LogManager.getLogger(MyStoreSearchResultsPage.class);
	private static MyStoreSearchResultsPage m_instance;
	
	
	
	private MyStoreSearchResultsPage(WebDriver _driver)
	{
		m_pageTitle = "My account - My Store";
		PageFactory.initElements(_driver, this);
		
	}
	
	public MyStoreItemDescriptionPage SelectItem(String _itemName)
	{
		log.debug("Selecting the item from Search Results");
		WebElement searchItem = SeleniumHelper.FindElement(By.linkText(_itemName));
		Selenium.Click(searchItem);
		SeleniumHelper.VerifyPageTitle(_itemName + " - My Store");
		
		return MyStoreItemDescriptionPage.GetInstance();
		
		
	}
	
	public static MyStoreSearchResultsPage GetInstance()
	{
		if (m_instance == null)
		{
			m_instance = new MyStoreSearchResultsPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}
