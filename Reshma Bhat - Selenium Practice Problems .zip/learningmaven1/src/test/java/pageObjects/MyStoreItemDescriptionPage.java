package pageObjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreItemDescriptionPage extends MyStorePageObject
{
	private static final Logger log = LogManager.getLogger(MyStoreSearchResultsPage.class);
	public static MyStoreItemDescriptionPage m_instance;
	
	@FindBy(name = "Submit")
    WebElement addToCartButton;
	
	@FindBy(xpath = "//*[@id=\"header\"]/div[3]/div/div/div[3]/div/a/b")
	WebElement shoppingCart;
	
	@FindBy(xpath = "//*[@id=\"footer\"]/div/section[5]/h4/a")
	WebElement myAccountLink;
	
	
	private MyStoreItemDescriptionPage(WebDriver _driver)
	{
		m_pageTitle = "My account - My Store";
		PageFactory.initElements(_driver, this);
	}
	
	
	public MyStoreItemAddedToCartWindow AddItemToCart()
	{
	   log.debug("Adding item to cart");	
	   Selenium.Click(addToCartButton);
	   
	   return MyStoreItemAddedToCartWindow.GetInstance();
		
	}
	
	public MyStoreShoppingCartPage goToShoppingCart()
	{
	  log.debug("Accessing the Shopping cart");
	  Selenium.Click(shoppingCart);
	  
	  SeleniumHelper.VerifyPageTitle("Order - My Store");
	  	  
	  return MyStoreShoppingCartPage.GetInstance();
		
	}
	
	/*public MyStoreMyAccountPage goToMyAccountPage()
	{
		log.debug("Accessing My Account page");
		Selenium.Click(myAccountLink);
		
		SeleniumHelper.VerifyPageTitle("My account - My Store");
		
		return MyStoreMyAccountPage.GetInstance();
		
	}*/
	
	public static MyStoreItemDescriptionPage GetInstance()
	{
		if (m_instance == null)
		{
			m_instance = new MyStoreItemDescriptionPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	
	}
	
	
}
