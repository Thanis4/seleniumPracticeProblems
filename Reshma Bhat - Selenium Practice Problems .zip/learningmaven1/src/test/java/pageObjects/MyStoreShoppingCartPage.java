package pageObjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

//import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreShoppingCartPage extends MyStorePageObject
{
	private static final Logger log = LogManager.getLogger(MyStoreSearchResultsPage.class);
	private static MyStoreShoppingCartPage m_instance;
	
	private MyStoreShoppingCartPage(WebDriver _driver)
	{
		m_pageTitle = "My account - My Store";
		PageFactory.initElements(_driver, this);
	}
	
	public MyStoreShoppingCartPage VerifyItemPresenceInCart(String _itemName)
	{
		
		Boolean presence = SeleniumHelper.VerifyTextPresentOnPage(_itemName);
		
		if (presence)
			{
			  log.debug(_itemName + " has been added to cart");
			  System.out.println("The item " + _itemName + " is added to cart");
			}
		else
		   {
			log.debug(_itemName + " not found in cart");
		    System.out.println("The item " + _itemName + " is not available in the cart");
		   }
		
		return MyStoreShoppingCartPage.GetInstance();
		
	}
	
	public static MyStoreShoppingCartPage GetInstance()
	{
		if (m_instance == null)
		{
			m_instance = new MyStoreShoppingCartPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}
