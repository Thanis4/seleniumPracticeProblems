package selenium;

public enum WebDriverType 
	
	{
		CHROME, FIREFOX, EDGE
		

    }
