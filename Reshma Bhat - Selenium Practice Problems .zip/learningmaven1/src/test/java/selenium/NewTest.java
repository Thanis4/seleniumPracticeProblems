package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import selenium.SeleniumHelper;

public class NewTest {
  @Test
  public void f() {
	  
	   SeleniumHelper sh = SeleniumHelper.GetInstance();
	     
	   WebDriver driver = sh.GetDriver();
	   
	   driver.get("http://www.google.com");
	   
	   System.out.println(driver.getTitle());
	   //System.out.println("***********************************************************************");
	   //System.out.println(driver.getPageSource());
	   By loc_searchField = By.name("q"); 
	   WebElement searchField = driver.findElement(loc_searchField);
	
		searchField.sendKeys("Automation Practice");
		searchField.submit();
	   
	   SeleniumHelper.Seconds(5);
	   
	   sh.CloseDriver();  
	   
	   
	   
  }
}
