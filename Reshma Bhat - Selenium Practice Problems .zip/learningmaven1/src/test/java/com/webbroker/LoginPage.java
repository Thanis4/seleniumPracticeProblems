package com.webbroker;

//import org.apache.log4j.LogManager;
//import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

//import selenium.Selenium;
//import org.openqa.selenium.support.FindBy;
import selenium.SeleniumHelper;

public class LoginPage {
	
	

	public static void main(String[] args) {
		
		
		System.setProperty("webdriver.chrome.driver", ".\\webdrivers\\chromedriver.exe");
		
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		WebDriver driver = new ChromeDriver(options);
		
		driver.get("https://authentication1.sys.td.com/uap-ui/index.html?consumer=webbroker&locale=en_CA#/login/webbroker-getting-started");
		
		 SeleniumHelper.Seconds(10);
		 
		 By loc_userName = By.xpath("//*[@name='username']");
		 WebElement userName =  driver.findElement(loc_userName);
		
		 By loc_password = By.id("password");
		 WebElement password = driver.findElement(loc_password);
		 
		 By loc_loginButton = By.xpath("//*[@id=\"loginForm\"]/div/div/div[3]/div/div/button");
         WebElement loginButton = driver.findElement(loc_loginButton);
         
              
        //Log.debug("Entering username and password in the Login page");
         
         userName.sendKeys("T0C5A1R1");
         password.sendKeys("abcde123");
         
         //Log.debug("Submitting login credentials....");
         loginButton.click();
         
         SeleniumHelper.Seconds(10);
         
         System.out.println(driver.getTitle());
         
         By loc_goalsTab = By.xpath("//*[@id=\"td-wb-menu-container\"]/div[1]/div[1]/div/td-wb-menu-local-navigation/div/td-wb-menu-flyout/div/td-wb-menu-item[6]/div/td-wb-menu-item-toggle/a/span");
         WebElement goalsTab = driver.findElement(loc_goalsTab);
         
         goalsTab.click();
         
         SeleniumHelper.Seconds(3);
         driver.switchTo().frame("main");
         
         By loc_addGoalButton = By.xpath("//span[contains(text(),'Add a goal')]");
         WebElement addGoalButton = driver.findElement(loc_addGoalButton);
         
         addGoalButton.click();
         
         /*SeleniumHelper.Seconds(3);
         
         By loc_selectDropDown = By.xpath("//*[@id='td-wb-lti-goal-selection']/div/div/div[2]");
         WebElement selectDropDown = driver.findElement(loc_selectDropDown);
         
         Selenium.SelectFromDropDown(selectDropDown, "retirement");*/
         
         driver.switchTo().defaultContent();
         
         By loc_logout = By.xpath("//*[@id=\"td-wb-menu-container\"]/div[1]/div[1]/div/td-wb-menu-top-navigation/data-td-wb-menu-flyout/div/td-wb-menu-item/div/ul/li[8]/a/span");
         WebElement logoutButton = driver.findElement(loc_logout);
         
         //Log.debug("Logging out....");
         logoutButton.click();
         
         SeleniumHelper.Seconds(3);
         driver.close();
         
                
         
	}

}
