package com.qac.tdseleniumtwo;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.MyStoreContactUsPage;
import pageObjects.MyStoreCreateAnAccountPage;
import pageObjects.MyStoreHomePage;
import pageObjects.MyStoreItemAddedToCartWindow;
import pageObjects.MyStoreItemDescriptionPage;
import pageObjects.MyStoreMyAccountPage;
import pageObjects.MyStorePageObject;
import pageObjects.MyStoreSearchResultsPage;
import pageObjects.MyStoreShoppingCartPage;
import pageObjects.MyStoreSignInPage;
import selenium.SeleniumHelper;
import pageObjects.MyStoreDressesPage;
import pageObjects.MyStoreCasualDressesPage;

public class StepDefs
{
MyStoreHomePage homePage = MyStoreHomePage.GetInstance();
MyStoreSignInPage signInPage = MyStoreSignInPage.GetInstance();
MyStoreCreateAnAccountPage createAccountPage = MyStoreCreateAnAccountPage.GetInstance();
MyStoreMyAccountPage myAccountPage = MyStoreMyAccountPage.GetInstance();
MyStoreContactUsPage contactUsPage = MyStoreContactUsPage.GetInstance();
MyStoreDressesPage dressesPage = MyStoreDressesPage.GetInstance();
MyStoreCasualDressesPage casualdressesPage = MyStoreCasualDressesPage.GetInstance();
MyStoreItemAddedToCartWindow cartItem = MyStoreItemAddedToCartWindow.GetInstance();
MyStoreItemDescriptionPage itemDescriptionPage = MyStoreItemDescriptionPage.GetInstance();
MyStoreShoppingCartPage shoppingCartPage = MyStoreShoppingCartPage.GetInstance();
MyStoreSearchResultsPage searchResultsPage = MyStoreSearchResultsPage.GetInstance();

@Given("^user is on homepage$")
public void user_is_on_homepage() throws Exception
{
homePage.NavigateToThisPage();
}
@When("^user navigates to signinpage$")
public void user_navigates_to_signinpage()
{
homePage.NavigateToSignInPage();
}
@When("user begins registration")
public void user_begins_registration()
{
signInPage.CreateAnAccount();
}
@When("user enters default data")
public void user_enters_default_data()
{
createAccountPage.EnterAccountDetails();
}
@When("user logs out")
public void user_logs_out()
{
myAccountPage.SignOut();
}
@Then("verify signinpage title")
public void verify_signinpage_title()
{
signInPage.VerifyTitle();
}
@When("user signs in")
public void user_signs_in()
{
signInPage.SignIn();
}
@Then("verify myaccountpage title")
public void verify_myaccountpage_title()
{
myAccountPage.VerifyTitle();
}
@When("user navigates to contactuspage")
public void user_navigates_to_contactuspage()
{
myAccountPage.NavigateToContactUsPage();
}
@Then("verify contactuspage title")
public void verify_contactuspage_title()
{
contactUsPage.VerifyTitle();
}

@When("user navigates to Dresses")
public void user_navigates_to_dressespage()
{
   dressesPage.NavigateToDressesPage();
}
@Then("verify dressespage title")
public void verify_dressespage_title()
{
   dressesPage.VerifyDressesHeader();
}
@When("user navigates to Casual Dresses")
public void user_navigates_to_casualdressespage()
{
	casualdressesPage.NavigateToCasualDressesPage();
}
@Then("verify casualdressespage title")
public void verify_casualdressespage_title()
{
	casualdressesPage.VerifyCasualDressesHeader();
}

@When("user searches for {string}")
public void user_searches_for(String string) 
   {
	searchResultsPage.SearchForItem(string);
	searchResultsPage.SelectItem(string);
	 
   }

@When("user clicks on Add to cart button")
public void user_clicks_on_Add_to_cart_button()
   {
	itemDescriptionPage.AddItemToCart();
	SeleniumHelper.Seconds(3);
    
   }

@When("user clicks on Continue shopping")
public void user_clicks_on_Continue_shopping()
   {
	cartItem.pressContinueShoppingButton();	
    
   }

@When("user clicks on Cart button")
public void user_clicks_on_Cart_button() 
   {
	itemDescriptionPage.goToShoppingCart();
    
   }

@Then("verify {string} is in cart")
public void verify_added_item_in_cart(String string) 
   {
	shoppingCartPage.VerifyItemPresenceInCart(string);
	SeleniumHelper.Seconds(1);
   }

@Then("sign out")
public void sign_out() 
   {
     MyStorePageObject.GetInstance().SignOut();
	
   }

}

