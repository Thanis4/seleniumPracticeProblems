package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreAboutUsPage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreAboutUsPage.class);
	private static MyStoreAboutUsPage m_instance;
	@FindBy(xpath = "//*[@id=\"center_column\"]/h1")
	WebElement contactUsHeader;
	@FindBy(linkText = "Sign in")
	WebElement signInButton;
	@FindBy(linkText = "Sign out")
	WebElement signOutButton;

	private MyStoreAboutUsPage(WebDriver _driver) {
		m_pageTitle = "Contact us - My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreAboutUsPage VerifyContactUsHeader() {
		Selenium.VerifyTextInElement(contactUsHeader, "CUSTOMER SERVICE - CONTACT US");
		return MyStoreAboutUsPage.GetInstance();
	}

	public MyStoreSignInPage NavigateToSignInPage() {
		log.debug("navigating to signin page");
		Selenium.Click(signInButton);
		return MyStoreSignInPage.GetInstance();
	}

	public static MyStoreAboutUsPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreAboutUsPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}
