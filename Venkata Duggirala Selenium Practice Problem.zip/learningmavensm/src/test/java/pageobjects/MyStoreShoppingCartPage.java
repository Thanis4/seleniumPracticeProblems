package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import selenium.SeleniumHelper;

public class MyStoreShoppingCartPage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreShoppingCartPage.class);
	private static MyStoreShoppingCartPage m_instance;

	private MyStoreShoppingCartPage(WebDriver _driver) {
		m_pageTitle = "My account - My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreShoppingCartPage VerifyItemPresenceInCart(String _itemName) {
		log.debug("Verifying item presence in the cart");
		if (SeleniumHelper.VerifyTextPresentOnPage(_itemName)) {
			log.info("The item " + _itemName + " was successfully found in cart");
		} else {
			log.error("The item " + _itemName + " was NOT found in cart");
		}
		return MyStoreShoppingCartPage.GetInstance();
	}

	public static MyStoreShoppingCartPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreShoppingCartPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}