package comqacunsultants.learningmaven;

import java.awt.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.Test;
import selenium.SeleniumHelper;

public class NewTestPageFactory {
	//@Test
	  public void f() {
		  // to open web browser//
		  SeleniumHelper sh = SeleniumHelper.GetInstance();
		  WebDriver driver = sh.GetDriver();
		  // to open Url//
		  driver.get("http://www.automationpractice.com");
		  
		  
		//  @FindBy(id="search_query_top") 
		  //WebElement searchButton;

		  
		  //System.out.println(driver.getTitle());//
		  
		 // SeleniumHelper.Seconds(5);//
		  
		 // sh.CloseDriver();//
		  
		  By loc_searchField = By.id("search_query_top"); 
		  WebElement searchField = driver.findElement(loc_searchField); 

		  searchField.sendKeys("Dresses");
		  
		  By loc_searchButton = By.name("submit_search"); 
		  WebElement searchButton = driver.findElement(loc_searchButton);
		  
		  searchButton.click();
		  
		  By loc_tShirtsLink = By.linkText("T-shirts");
		  WebElement tShirtsLink = driver.findElement(loc_tShirtsLink);
		  
		  tShirtsLink.click();
	}
}