package com.qac.tdseleniumtwo;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.MyStoreProcessAddressPage;
import pageobjects.MyStoreAddressPage;
import pageobjects.MyStoreContactUsPage;
import pageobjects.MyStoreCreateAnAccountPage;
import pageobjects.MyStoreHomePage;
import pageobjects.MyStoreItemAddedToCartWindow;
import pageobjects.MyStoreItemDescriptionPage;
import pageobjects.MyStoreMyAccountPage;
import pageobjects.MyStorePaymentPage;
import pageobjects.MyStoreSignInPage;
import selenium.SeleniumHelper;
import pageobjects.MyStoreSearchResultPage;
import pageobjects.MyStoreSearchResultsPage;
import pageobjects.MyStoreShippingPage;
import pageobjects.MyStoreShoppingCartPage;

public class Stepdefs
{
MyStoreHomePage homePage = MyStoreHomePage.GetInstance();
MyStoreSignInPage signInPage = MyStoreSignInPage.GetInstance();
MyStoreCreateAnAccountPage createAccountPage =
MyStoreCreateAnAccountPage.GetInstance();
MyStoreMyAccountPage myAccountPage =
MyStoreMyAccountPage.GetInstance();
MyStoreContactUsPage contactUsPage =
MyStoreContactUsPage.GetInstance();

MyStoreSearchResultPage searchResults = MyStoreSearchResultPage.GetInstance();

MyStoreSearchResultsPage searchResultsPage = MyStoreSearchResultsPage.GetInstance();
MyStoreItemDescriptionPage itemDescriptionPage = MyStoreItemDescriptionPage.GetInstance();
MyStoreItemAddedToCartWindow itemAddedToCartWindow = MyStoreItemAddedToCartWindow.GetInstance();
MyStoreShoppingCartPage shoppingCartPage = MyStoreShoppingCartPage.GetInstance();
MyStoreAddressPage addressPage = MyStoreAddressPage.GetInstance();
MyStoreProcessAddressPage processAddressPage = MyStoreProcessAddressPage.GetInstance();
MyStoreShippingPage shippingPage = MyStoreShippingPage.GetInstance();
MyStorePaymentPage paymentPage = MyStorePaymentPage.GetInstance();

@Given("^user is on homepage$")
public void user_is_on_homepage() throws Exception
{
homePage.NavigateToThisPage();
}
@When("^user navigates to signinpage$")
public void user_navigates_to_signinpage()
{
homePage.NavigateToSignInPage();
}
@When("user begins registration")
public void user_begins_registration()
{
signInPage.CreateAnAccount();
}
@When("user enters default data")
public void user_enters_default_data()
{
createAccountPage.EnterAccountDetails();
}
@When("user logs out")
public void user_logs_out()
{
myAccountPage.SignOut();
}
@Then("verify signinpage title")
public void verify_signinpage_title()
{
signInPage.VerifyTitle();
}
@When("user signs in")
public void user_signs_in()
{
signInPage.SignIn();
}
@Then("verify myaccountpage title")
public void verify_myaccountpage_title()
{
myAccountPage.VerifyTitle();
}
@When("user navigates to contactuspage")
public void user_navigates_to_contactuspage()
{
myAccountPage.NavigateToContactUsPage();
}
@Then("verify contactuspage title")
public void verify_contactuspage_title()
{
contactUsPage.VerifyTitle();
}

@When("user enter dresses")
public void user_enter_dresses() {
    // Write code here that turns the phrase above into concrete actions
    homePage.enterTextSearch();
}

@When("user clicks search button")
public void user_clicks_search_button() {
    // Write code here that turns the phrase above into concrete actions
    homePage.clickSearchButton();
}

@Then("verify search result page is displayed")
public void verify_search_result_page_is_displayed() {
	searchResults.VerifyTitle();
}

@When("user searches for {string}")
public void user_searches_for(String string)
{
myAccountPage.SearchForItem(string);
searchResultsPage.SelectItem(string);
}
@When("user adds item to cart")
public void user_adds_item_to_cart()
{
itemDescriptionPage.AddItemToCart();
SeleniumHelper.Seconds(5);
}
@When("user continues shopping")
public void user_continues_shopping()
{
itemAddedToCartWindow.pressContinueShoppingButton();
SeleniumHelper.Seconds(5);
}
@When("user selects colour option Blue")
public void user_selects_colour_option_Blue() {
    
	// Write code here that turns the phrase above into concrete actions
	itemDescriptionPage.clickBlueOption();
}


@When("user clicks shopping cart")
public void user_clicks_shopping_cart()
{
itemDescriptionPage.goToShoppingCart();
}



@Then("user verifies {string} is in cart")
public void user_verifies_is_in_cart(String string)
{
shoppingCartPage.VerifyItemPresenceInCart(string);
}


//@When("user clicks proceed to check out")
//public void user_clicks_proceedtocheckout()
//{
//shoppingCartPage.proceedToCheckout();
//}

@When("user clicks Proceed to checkout button")
public void user_clicks_Proceed_to_checkout_button() 

{
    // Write code here that turns the phrase above into concrete actions
	addressPage.ClickProceedToCheckout();
}

@Then("user clicks Proceed to checkout button on process Address page")
public void user_clicks_Proceed_to_checkout_button_process_Address() 

{
    //Write code here that turns the phrase above into concrete actions
	processAddressPage.ClickProceedToCheckout();
}
@Then("user clicks the Terms of Service checkbox")
public void user_clicks_the_Terms_of_Service_checkbox() {
    // Write code here that turns the phrase above into concrete actions
    shippingPage.click_agree_to_term();
}


@Then("user clicks Proceed to checkout button on process Carrier page")
public void user_clicks_Proceed_to_checkout_button_on_process_Carrier_page() {
    // Write code here that turns the phrase above into concrete actions
	shippingPage.ClickProceedToCheckout();
}

@Then("user clicks Pay By Check button")
public void user_clicks_Pay_By_Check_button() {
    // Write code here that turns the phrase above into concrete actions
	paymentPage.PayByCheck();
}

@Then("user verifies CHECK PAYMENT is displayed")
public void user_verifies_CHECK_PAYMENT_is_displayed() 
{
    // Write code here that turns the phrase above into concrete actions
    paymentPage.VerifyChkPay();
}

@Then("user clicks I Confirm My Order button")
public void user_clicks_I_Confirm_My_Order_button() 
{
    // Write code here that turns the phrase above into concrete actions
    paymentPage.ConfirmOrder();
  }

@Then("user verifies Your order on My Store is complete. is displayed")
public void user_verifies_alert_message_is_displayed() 
{
    // Write code here that turns the phrase above into concrete actions
    paymentPage.VerifyCompletion();
}

@Then("user signs out")
public void user_signs_out()
{
shoppingCartPage.SignOut();
}



}


