package pageobjects;
import java.lang.reflect.Array;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;
public class MyStoreAddressPage extends MyStorePageObject
{
  
		@FindBy(xpath = "//a[@title = 'Proceed to checkout']")
		List<WebElement> checkoutButtons; 
 

// static webelement proceedToCheckOut = checkoutButtons[1];

//static WebElement proceedToCheckOut;
private static final Logger log = LogManager.getLogger(MyStoreAddressPage.class);
private static MyStoreAddressPage m_instance;
private MyStoreAddressPage(WebDriver _driver)
{
m_pageTitle = "My account - My Store";
PageFactory.initElements(_driver, this);
}
public MyStoreAddressPage VerifyItemPresenceInCart(String _itemName)
{
log.debug("Verifying item presence in the cart");
if (SeleniumHelper.VerifyTextPresentOnPage(_itemName))
{
log.info("The item " + _itemName + " was successfully found in cart");
}
else
{
log.error("The item " + _itemName + " was NOT found in cart");
}
return MyStoreAddressPage.GetInstance();
}




public MyStoreAddressPage ClickProceedToCheckout() {
	// TODO Auto-generated method stub
//for(int i=1; i>=0; i--)	
{
WebElement checkoutBtn = checkoutButtons.get(1);
	
	checkoutBtn.click();
	
	return MyStoreAddressPage.GetInstance();
	
}


	
	
	
}

public static MyStoreAddressPage GetInstance()
{
if (m_instance == null)
{
m_instance = new MyStoreAddressPage(SeleniumHelper.GetInstance().GetDriver());
}
return m_instance;
}

}

