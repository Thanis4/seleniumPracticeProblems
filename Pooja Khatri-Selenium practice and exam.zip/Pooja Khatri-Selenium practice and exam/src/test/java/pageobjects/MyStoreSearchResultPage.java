	package pageobjects;
	import org.apache.log4j.LogManager;
	import org.apache.log4j.Logger;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;
	import selenium.Selenium;
	import selenium.SeleniumHelper;
	public class MyStoreSearchResultPage extends MyStorePageObject
	{
	public static final Logger log =
	LogManager.getLogger(MyStoreHomePage.class);
	public static MyStoreSearchResultPage m_instance;
	public String m_url;
	
	
		public MyStoreSearchResultPage(WebDriver _driver)
		  
		  {
		  //log.debug("creating Home Page PageObject");
		  m_url = "http://automationpractice.com/index.php";
		  m_pageTitle = "Search - My Store";
		  PageFactory.initElements(_driver, this);
		  }
		
		public static MyStoreSearchResultPage GetInstance()
		{
		if (m_instance == null)
		{
		m_instance = new MyStoreSearchResultPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
		}
	  }
	
