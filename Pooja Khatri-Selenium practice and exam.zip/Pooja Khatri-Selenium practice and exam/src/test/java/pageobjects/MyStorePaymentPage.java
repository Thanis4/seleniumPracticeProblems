package pageobjects;
import java.lang.reflect.Array;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;
public class MyStorePaymentPage extends MyStorePageObject
{
  
		@FindBy(xpath = "//a[@title = 'Pay by check.']")
		List<WebElement> paybyCheckButton; 
 
		//@FindBy(xpath = "//a[@title = 'I confirm my order']")
		//List<WebElement> confirmorderButton;

		//@FindBy(linkText = "I confirm my order")
			
		//@FindBy(id = "cart_navigation")
		@FindBy(xpath = "//*[@id='cart_navigation']/button")
		WebElement confirmorderButton;
// static webelement proceedToCheckOut = checkoutButtons[1];

//static WebElement proceedToCheckOut;
private static final Logger log = LogManager.getLogger(MyStorePaymentPage.class);
private static MyStorePaymentPage m_instance;
private MyStorePaymentPage(WebDriver _driver)
{
m_pageTitle = "My account - My Store";
PageFactory.initElements(_driver, this);
}

public MyStorePaymentPage PayByCheck() 
	
{
WebElement paybyCheckBtn = paybyCheckButton.get(0);
	
     paybyCheckBtn.click();
	
	return MyStorePaymentPage.GetInstance();
	
}

public MyStorePaymentPage VerifyChkPay() 

{
	// TODO Auto-generated method stub
	SeleniumHelper.VerifyTextPresentOnPage("Check payment");
	
	return MyStorePaymentPage.GetInstance();
}


public MyStorePaymentPage ConfirmOrder() {
	// TODO Auto-generated method stub
	//WebElement cfrmorderBtn = confirmorderButton.get(0);
	
	  //cfrmorderBtn.click();
	
	confirmorderButton.click();
	  
	  return MyStorePaymentPage.GetInstance();
		
	
}


public MyStorePaymentPage VerifyCompletion() {
	SeleniumHelper.VerifyTextPresentOnPage("Your order on My Store is complete.");
	return MyStorePaymentPage.GetInstance();
	
}


public static MyStorePaymentPage GetInstance()
{
if (m_instance == null)
{
m_instance = new MyStorePaymentPage(SeleniumHelper.GetInstance().GetDriver());
}
return m_instance;
}





}

