package pageobjects;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;
public class MyStoreSearchResultsPage extends MyStorePageObject
{
private static final Logger log = LogManager.getLogger(MyStoreSearchResultsPage.class);
private static MyStoreSearchResultsPage m_instance;
private MyStoreSearchResultsPage(WebDriver _driver)
{
m_pageTitle = "My account - My Store";
PageFactory.initElements(_driver, this);
}
public MyStoreItemDescriptionPage SelectItem(String _itemName)
{
log.debug("Selecting item");
WebElement itemToBeSelected = SeleniumHelper.FindElement(By.linkText(_itemName));

if (_itemName == ("Faded Short Sleeve T-shirts"))
	{
	Selenium.Click(blueButton);
	}
if (itemToBeSelected.isDisplayed())
{
itemToBeSelected.click();
if (SeleniumHelper.VerifyPageTitle(_itemName))
{
	log.info("Successfully selected the item " + _itemName);
	}
	else
	{
	log.error("Failed to select the item " + _itemName);
	}
	}
	else
	{
	log.error("The searched item was not found");
	}
	return MyStoreItemDescriptionPage.GetInstance();
	}
	
	public static MyStoreSearchResultsPage GetInstance()
	{
	if (m_instance == null)
	{
	m_instance = new MyStoreSearchResultsPage(SeleniumHelper.GetInstance().GetDriver());
	}
	return m_instance;
	}
}

