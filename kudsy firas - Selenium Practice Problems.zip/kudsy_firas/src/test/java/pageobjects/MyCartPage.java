package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyCartPage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyCartPage.class);
	private static MyCartPage m_instance;

	
	
	
	@FindBy(xpath = "//*[@id=\"center_column\"]/p[2]/a[1]")
	WebElement checkoutButton;
	
	@FindBy(xpath = "//*[@id=\"cart_navigation\"]/button")
	WebElement confirmButton;
	
	
	@FindBy(linkText = "Pay by check.")
	WebElement payByCheckButton;
	
	@FindBy(linkText = "Log me out")
	WebElement signoutButton;
	
	private MyCartPage(WebDriver _driver) {
		m_pageTitle = "Order - My Store";
		PageFactory.initElements(_driver, this);
	}
	
	public MyCartPage NavigateToProceedToCheckoutPage() {
		Selenium.Click(checkoutButton);		
		return MyCartPage.GetInstance();
	}
	
	
	public MyCartPage PayByCheck() {
		Selenium.Click(payByCheckButton);		
		return MyCartPage.GetInstance();
	}
	
	
	public MyCartPage AgreeTermsServices() {
		
		Selenium.CheckBox(By.id("cgv"), true);
		Selenium.Click(checkoutButton);		
		return MyCartPage.GetInstance();
	}
	
	public MyCartPage ConfirmPayment() {
		
		Selenium.Click(confirmButton);

		return MyCartPage.GetInstance();
	}
	
	
	public MyStoreSignInPage SignOut() {
		

		Selenium.Click(signoutButton);

		return MyStoreSignInPage.GetInstance();
	}

	

	public MyCartPage VerifyOrderComplete() {
		
		log.debug("virefiy  order complete ");
		if (SeleniumHelper.VerifyTextPresentOnPage("Your order on My Store is complete.")) {
			log.info("Verify order complete Done");

		} else {
			log.info("Verify order complete Error");
			throw new AssertionError("Verify order conplete");
		}
	

		return MyCartPage.GetInstance();
	}

	
	public MyCartPage VerifyCheckPayment() {
		
		log.debug("virefiy  check paymnet ");
		if (SeleniumHelper.VerifyTextPresentOnPage("CHECK PAYMENT")) {
			log.info("Verify check paymnet Done");

		} else {
			log.info("Verify check paymnet Error");
			throw new AssertionError("Verify check paymnet");
		}
	

		return MyCartPage.GetInstance();
	}

	public static MyCartPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyCartPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}