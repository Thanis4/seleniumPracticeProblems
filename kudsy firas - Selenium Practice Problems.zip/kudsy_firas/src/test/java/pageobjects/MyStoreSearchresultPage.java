package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreSearchresultPage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreSearchresultPage.class);
	private static MyStoreSearchresultPage m_instance;
	
	@FindBy(xpath = "//*[@id=\"center_column\"]/h1")
	WebElement contactUsHeader;
	@FindBy(linkText = "Sign in")
	WebElement signInButton;
	@FindBy(linkText = "Sign out")
	WebElement signOutButton;

	private MyStoreSearchresultPage(WebDriver _driver) {
		m_pageTitle = "Search - My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreSearchresultPage VerifySearchresultTitle() {
		Selenium.VerifyTextInElement(contactUsHeader, "CUSTOMER SERVICE - CONTACT US");
		return MyStoreSearchresultPage.GetInstance();
	}

	
	public static MyStoreSearchresultPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreSearchresultPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}