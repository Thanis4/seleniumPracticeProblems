package com.qac.tdseleniumtwo;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.MyCartPage;
import pageobjects.MyStoreHomePage;
import pageobjects.MyStoreMyAccountPage;
import pageobjects.MyStoreSearchresultPage;
import pageobjects.MyStoreSignInPage;


public class Stepdefs {


	MyStoreHomePage homePage = MyStoreHomePage.GetInstance();
	MyStoreSignInPage signInPage = MyStoreSignInPage.GetInstance();
	MyCartPage cartPage = MyCartPage.GetInstance();
	MyStoreMyAccountPage myAccoutnPage = MyStoreMyAccountPage.GetInstance();
	MyStoreSearchresultPage searchResultPage = MyStoreSearchresultPage.GetInstance();

	@Given("^user is on homepage$")
	public void user_is_on_homepage() throws Exception {
		homePage.NavigateToThisPage();
	}

	@When("^user navigates to signinpage$")
	public void user_navigates_to_signinpage() {
		homePage.NavigateToSignInPage();
	}
	
	@When("user sign in with email address and password")
	public void user_sign_in_with_email_address_and_password() {
		signInPage.SignIn();
	}
	
	@Then("verify signinpage title")
	public void verify_signinpage_title() {
		signInPage.VerifyTitle();
	}


	//	
	//
	
	@Given("^user is on myaccount$")
	public void user_is_on_myaccount() throws Exception {
		homePage.NavigateToMyAccountPage();
	}
	
	@When("^user search and add product to cart$")
	public void user_search_and_add_product_to_cart() {
		homePage.SearchForProduct();
	}
	

	@When("^user search more product and add cart$")
	public void user_search_more_product_and_add_cart() {
		homePage.SearchForMoreProducts();
	}
	
	
	@Given("^user is on cartpage$")
	public void user_is_on_cartpage() throws Exception {
		homePage.NavigateToCartPage();
	}
	
	@Then("verify cart page")
	public void verify_cart_page() {
//		searchResultPage.VerifyTitle();
		homePage.VerifyCartPage();

	}

	
	@Then("verify product added")
	public void verify_product_added() {
//		searchResultPage.VerifyTitle();
		homePage.VerifyCart();

	}

	@When("user logs out")
	public void user_logs_out() {
		myAccoutnPage.SignOut();
	}


	@When("user signs in")
	public void user_signs_in() {
		signInPage.SignIn();
	}

	@When("user navigatre to proceed to checkout")
	public void user_navigatre_to_proceed_to_checkout() {
		cartPage.NavigateToProceedToCheckoutPage();
	}

	@When("user pay by check")
	public void user_pay_by_check() {
		cartPage.PayByCheck();
	}

	
	@When("user agree on terms of services")
	public void user_agree_on_terms_of_services() {
		cartPage.AgreeTermsServices();
	}
	
	
	@When("user use confirm payment")
	public void use_confirm_payment() {
		cartPage.ConfirmPayment();
	}
	
	
	@When("user signout")
	public void use_signout() {
		cartPage.SignOut();
	}
	
	
	
	
	
	
	@Then("verify order complete")
	public void verify_order_complete() {
		cartPage.VerifyOrderComplete();
	}
	
	
	@Then("verify check payment")
	public void verify_check_payment() {
		cartPage.VerifyCheckPayment();
	}

	
	
	
	@Then("verify myaccountpage title")
	public void verify_myaccountpage_title() {
		myAccoutnPage.VerifyTitle();
	}


	@Then("verify contactuspage title")
	public void verify_contactuspage_title() {
		searchResultPage.VerifyTitle();
	}
}