package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreMyCartPage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreMyCartPage.class);
	private static MyStoreMyCartPage m_instance;
	@FindBy(xpath = "//*[@id=\"center_column\"]/h1")
	WebElement cartHeader;
	@FindBy(linkText = "Sign in")
	WebElement signInButton;
	@FindBy(linkText = "Sign out")
	WebElement signOutButton;

	private MyStoreMyCartPage(WebDriver _driver) {
		m_pageTitle = "Cart - My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreMyCartPage VerifycartHeader() {
		Selenium.VerifyTextInElement(cartHeader, "CUSTOMER SERVICE - CART");
		return MyStoreMyCartPage.GetInstance();
	}

	public MyStoreSignInPage NavigateToSignInPage() {
		log.debug("navigating to signin page");
		Selenium.Click(signInButton);
		return MyStoreSignInPage.GetInstance();
	}

	public static MyStoreMyCartPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreMyCartPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}