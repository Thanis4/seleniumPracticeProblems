package com.qaconsultants.learningmaven;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import selenium.SeleniumHelper;

@CucumberOptions(plugin = { "pretty" }, features = "src/test/java/feature_files/")
public class RunCucumberTest extends AbstractTestNGCucumberTests {
	private final Logger log = LogManager.getLogger(RunCucumberTest.class);

	@DataProvider(parallel = false)
	@Override
	public Object[][] scenarios() {
		return super.scenarios();
	}

	@BeforeSuite
	public void beforeSuite() {
		log.info("starting Suite");
	}

	@AfterSuite
	public void afterSuite() {
		log.info("finishing Suite");
		SeleniumHelper.GetInstance().CloseDriver();
	}

	static {
		System.setProperty("logfiletimestamp", new SimpleDateFormat("yyyy_MM_dd HH_MM_ss").format(new Date()));
	}
}