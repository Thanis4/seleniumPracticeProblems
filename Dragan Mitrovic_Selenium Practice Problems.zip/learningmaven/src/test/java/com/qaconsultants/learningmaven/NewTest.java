package com.qaconsultants.learningmaven;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import selenium.SeleniumHelper;

public class NewTest {
	@Test
	public void f() {
		SeleniumHelper sh = SeleniumHelper.GetInstance();
		WebDriver driver = sh.GetDriver();

		driver.get("http://www.google.ca");

		By loc_searchField = By.name("q");
		WebElement searchField = driver.findElement(loc_searchField);
		searchField.sendKeys("airbnb");
		searchField.sendKeys(Keys.ENTER);

		System.out.println(driver.getPageSource());

		SeleniumHelper.Seconds(5);

		sh.CloseDriver();
	}
}
